package model.business;

import java;

import control.LoginSuccessView;
import model.entities.MessageException;

public class LoginBusiness extends java {
	if (userName.equals("")) {
		throw new MessageException("Username not informed.");
	} else if (password.equals("")) {
		throw new MessageException("Password not informed.");
	} 
	
	User user = new User(userName, password);
	
		
	if (!(new LoginDataAccess().verifyCredentials(user))) {
		throw new MessageException("Incorrect credentials.");
	} else {
		request.setAttribute("Username", request.getParameter("username"));
		address = "/view/LoginSuccessView.jsp";
}
